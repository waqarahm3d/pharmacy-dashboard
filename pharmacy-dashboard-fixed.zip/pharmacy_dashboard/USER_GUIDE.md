# Pharmacy Dashboard - User Guide

## Welcome to Your Pharmacy Dashboard

This user guide will help you get started with your new NHS Pharmacy Financial Analytics Platform.

## 🎯 What You Can Do

### Dashboard Overview
- **View Key Metrics**: Total account values, active pharmacies, drug costs
- **Analyze Trends**: Monthly financial performance charts
- **Compare Pharmacies**: Performance rankings and comparisons
- **Track Costs**: Breakdown of different cost categories

### PDF Upload & Processing
- **Upload NHS Pharmacy Schedules**: Drag and drop PDF files
- **Automatic Data Extraction**: System processes PDFs automatically
- **Real-time Updates**: Dashboard updates immediately with new data
- **Error Handling**: Clear feedback on processing status

### User Management
- **Role-based Access**: Admin, Manager, and Viewer roles
- **Secure Login**: JWT-based authentication
- **User Profiles**: Manage user information and permissions

## 🚀 Getting Started

### First Login
1. Open your browser and go to the dashboard URL
2. Use the default credentials:
   - **Username**: admin
   - **Password**: admin123
3. **Important**: Change your password immediately after first login

### Navigating the Dashboard
- **Sidebar Navigation**: Click on different sections (Dashboard, Pharmacies, Analytics, Upload, Settings)
- **Search Bar**: Find specific pharmacies or reports quickly
- **User Menu**: Access profile settings and logout

### Uploading Your First PDF
1. Click on "Upload" in the sidebar
2. Drag and drop your NHS pharmacy schedule PDF
3. Wait for processing to complete
4. View the updated data in the Dashboard

## 📊 Understanding Your Data

### Key Metrics Cards
- **Total Account Value**: Sum of all pharmacy accounts
- **Active Pharmacies**: Number of pharmacies with recent data
- **Drug & Appliance Costs**: Total medication costs
- **Total Reports**: Number of processed PDF reports

### Charts and Visualizations
- **Monthly Trends**: Line chart showing financial performance over time
- **Cost Breakdown**: Pie chart showing distribution of costs
- **Pharmacy Performance**: Table ranking pharmacies by total account value

### Data Filters
- **Time Range**: Filter data by specific months or date ranges
- **Pharmacy Selection**: Focus on specific pharmacy branches
- **Cost Categories**: Filter by different types of costs

## 🔧 Administration

### User Management (Admin Only)
- **Add New Users**: Create accounts for staff members
- **Assign Roles**: Set appropriate permissions for each user
- **Manage Access**: Enable or disable user accounts

### Data Management
- **Export Data**: Download reports in Excel or CSV format
- **Backup**: Regular data backups are handled automatically
- **Data Validation**: System validates all uploaded data

### System Settings
- **Update Profile**: Change your personal information
- **Security Settings**: Update passwords and security preferences
- **Notification Preferences**: Configure email alerts and updates

## 📈 Advanced Features

### Analytics and Reporting
- **Trend Analysis**: Identify patterns in financial data
- **Performance Metrics**: Compare pharmacy efficiency
- **Growth Calculations**: Automatic calculation of month-over-month changes
- **Custom Reports**: Generate reports for specific time periods

### Data Export Options
- **Excel Export**: Download data in spreadsheet format
- **PDF Reports**: Generate formatted reports for printing
- **CSV Data**: Export raw data for further analysis

## 🔒 Security Best Practices

### Password Security
- Use strong, unique passwords
- Change passwords regularly
- Don't share login credentials

### Data Protection
- Log out when finished using the system
- Don't leave the dashboard open on shared computers
- Report any suspicious activity immediately

### Access Control
- Only grant necessary permissions to users
- Regularly review user access levels
- Remove access for users who no longer need it

## 🆘 Troubleshooting

### Common Issues

**Login Problems**
- Check username and password spelling
- Ensure Caps Lock is off
- Contact administrator if account is locked

**PDF Upload Issues**
- Ensure PDF is a valid NHS pharmacy schedule
- Check file size (maximum 16MB)
- Try uploading one file at a time

**Dashboard Not Loading**
- Refresh your browser
- Clear browser cache and cookies
- Check internet connection

**Data Not Updating**
- Wait a few moments for processing to complete
- Refresh the page
- Check if PDF upload was successful

### Getting Help
1. Check this user guide first
2. Contact your system administrator
3. Review the technical documentation
4. Submit a support ticket if available

## 📞 Support Information

### Technical Support
- **System Administrator**: Contact your local IT support
- **Documentation**: Refer to README.md and DEPLOYMENT.md
- **Emergency Issues**: Contact immediately if data security is compromised

### Training Resources
- **User Guide**: This document
- **Video Tutorials**: Available from your administrator
- **Hands-on Training**: Schedule with your IT team

## 🔄 Regular Maintenance

### Daily Tasks
- Check dashboard for new data
- Upload any new PDF reports
- Review key metrics and trends

### Weekly Tasks
- Export reports as needed
- Review user access and permissions
- Check for system updates

### Monthly Tasks
- Review overall performance trends
- Generate monthly reports
- Backup important data

## 📋 Quick Reference

### Keyboard Shortcuts
- **Ctrl+D**: Go to Dashboard
- **Ctrl+U**: Go to Upload page
- **Ctrl+L**: Logout
- **Ctrl+S**: Search

### Important URLs
- **Dashboard**: /dashboard
- **Upload**: /upload
- **Pharmacies**: /pharmacies
- **Analytics**: /analytics
- **Settings**: /settings

### File Formats Supported
- **PDF**: NHS pharmacy schedule PDFs
- **Export Formats**: Excel (.xlsx), CSV (.csv), PDF reports

---

**Need more help?** Contact your system administrator or refer to the technical documentation.

**Remember**: Always keep your login credentials secure and log out when finished!

