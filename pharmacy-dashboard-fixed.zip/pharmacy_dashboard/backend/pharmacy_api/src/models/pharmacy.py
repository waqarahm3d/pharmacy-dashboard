from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from datetime import datetime
from werkzeug.security import generate_password_hash, check_password_hash
from flask_jwt_extended import create_access_token
import enum

db = SQLAlchemy()
migrate = Migrate()


class UserRole(enum.Enum):
    ADMIN = "admin"
    MANAGER = "manager"
    VIEWER = "viewer"


class User(db.Model):
    """User model for authentication and authorization."""
    __tablename__ = 'users'
    
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    role = db.Column(db.Enum(UserRole), nullable=False, default=UserRole.VIEWER)
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    last_login = db.Column(db.DateTime)
    
    def set_password(self, password):
        """Set password hash."""
        self.password_hash = generate_password_hash(password)
    
    def check_password(self, password):
        """Check password against hash."""
        return check_password_hash(self.password_hash, password)
    
    def generate_token(self):
        """Generate JWT token for user."""
        return create_access_token(identity=self.id)
    
    def to_dict(self):
        """Convert user to dictionary."""
        return {
            'id': self.id,
            'username': self.username,
            'email': self.email,
            'role': self.role.value,
            'is_active': self.is_active,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'last_login': self.last_login.isoformat() if self.last_login else None
        }


class Pharmacy(db.Model):
    """Pharmacy model for storing pharmacy information."""
    __tablename__ = 'pharmacies'
    
    id = db.Column(db.Integer, primary_key=True)
    ocs_code = db.Column(db.String(20), unique=True, nullable=False, index=True)
    branch_name = db.Column(db.String(255), nullable=False)
    address = db.Column(db.Text)
    postcode = db.Column(db.String(20))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationship to financial records
    financial_records = db.relationship('FinancialRecord', backref='pharmacy', lazy=True, cascade='all, delete-orphan')
    
    def to_dict(self):
        """Convert pharmacy to dictionary."""
        return {
            'id': self.id,
            'ocs_code': self.ocs_code,
            'branch_name': self.branch_name,
            'address': self.address,
            'postcode': self.postcode,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }


class FinancialRecord(db.Model):
    """Financial record model for storing monthly pharmacy financial data."""
    __tablename__ = 'financial_records'
    
    id = db.Column(db.Integer, primary_key=True)
    pharmacy_id = db.Column(db.Integer, db.ForeignKey('pharmacies.id'), nullable=False)
    
    # Date information
    dispensing_month = db.Column(db.String(20), nullable=False)  # e.g., "Mar 2025"
    dispensing_date = db.Column(db.Date, nullable=False)  # Parsed date for easier querying
    
    # Core financial metrics
    total_account = db.Column(db.Numeric(12, 2), nullable=False, default=0)
    drug_appliance_costs = db.Column(db.Numeric(12, 2), nullable=False, default=0)
    prescription_fees = db.Column(db.Numeric(12, 2), nullable=False, default=0)
    other_fees = db.Column(db.Numeric(12, 2), nullable=False, default=0)
    charges = db.Column(db.Numeric(12, 2), nullable=False, default=0)
    
    # Calculated metrics
    drug_costs_percentage = db.Column(db.Numeric(5, 2), default=0)
    prescription_fees_percentage = db.Column(db.Numeric(5, 2), default=0)
    other_fees_percentage = db.Column(db.Numeric(5, 2), default=0)
    total_fees = db.Column(db.Numeric(12, 2), default=0)
    
    # File information
    source_file_name = db.Column(db.String(255))
    source_file_path = db.Column(db.String(500))
    
    # Metadata
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    created_by = db.Column(db.Integer, db.ForeignKey('users.id'))
    
    # Unique constraint to prevent duplicate records
    __table_args__ = (
        db.UniqueConstraint('pharmacy_id', 'dispensing_date', name='unique_pharmacy_month'),
    )
    
    def to_dict(self):
        """Convert financial record to dictionary."""
        return {
            'id': self.id,
            'pharmacy_id': self.pharmacy_id,
            'dispensing_month': self.dispensing_month,
            'dispensing_date': self.dispensing_date.isoformat() if self.dispensing_date else None,
            'total_account': float(self.total_account) if self.total_account else 0,
            'drug_appliance_costs': float(self.drug_appliance_costs) if self.drug_appliance_costs else 0,
            'prescription_fees': float(self.prescription_fees) if self.prescription_fees else 0,
            'other_fees': float(self.other_fees) if self.other_fees else 0,
            'charges': float(self.charges) if self.charges else 0,
            'drug_costs_percentage': float(self.drug_costs_percentage) if self.drug_costs_percentage else 0,
            'prescription_fees_percentage': float(self.prescription_fees_percentage) if self.prescription_fees_percentage else 0,
            'other_fees_percentage': float(self.other_fees_percentage) if self.other_fees_percentage else 0,
            'total_fees': float(self.total_fees) if self.total_fees else 0,
            'source_file_name': self.source_file_name,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }


class UploadLog(db.Model):
    """Log of PDF file uploads and processing."""
    __tablename__ = 'upload_logs'
    
    id = db.Column(db.Integer, primary_key=True)
    file_name = db.Column(db.String(255), nullable=False)
    file_size = db.Column(db.Integer)
    file_hash = db.Column(db.String(64))  # SHA-256 hash to detect duplicates
    
    # Processing status
    status = db.Column(db.String(20), default='pending')  # pending, processing, completed, failed
    error_message = db.Column(db.Text)
    
    # Results
    records_created = db.Column(db.Integer, default=0)
    records_updated = db.Column(db.Integer, default=0)
    
    # Metadata
    uploaded_by = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    uploaded_at = db.Column(db.DateTime, default=datetime.utcnow)
    processed_at = db.Column(db.DateTime)
    
    def to_dict(self):
        """Convert upload log to dictionary."""
        return {
            'id': self.id,
            'file_name': self.file_name,
            'file_size': self.file_size,
            'status': self.status,
            'error_message': self.error_message,
            'records_created': self.records_created,
            'records_updated': self.records_updated,
            'uploaded_by': self.uploaded_by,
            'uploaded_at': self.uploaded_at.isoformat() if self.uploaded_at else None,
            'processed_at': self.processed_at.isoformat() if self.processed_at else None
        }

