"""
Data service for processing pharmacy PDFs and managing database operations.
"""

import os
import sys
import hashlib
from datetime import datetime
from dateutil.parser import parse

# Add the parent directory to the path to import from src
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from src.models.pharmacy import db, Pharmacy, FinancialRecord, UploadLog
from pdf_extractor import PharmacyDataExtractor


class PharmacyDataService:
    """Service for processing pharmacy data and managing database operations."""
    
    def __init__(self, app=None):
        self.app = app
        self.extractor = PharmacyDataExtractor()
    
    def calculate_file_hash(self, file_path):
        """Calculate SHA-256 hash of a file."""
        hash_sha256 = hashlib.sha256()
        with open(file_path, "rb") as f:
            for chunk in iter(lambda: f.read(4096), b""):
                hash_sha256.update(chunk)
        return hash_sha256.hexdigest()
    
    def parse_dispensing_date(self, dispensing_month):
        """Parse dispensing month string to date object."""
        try:
            # Handle formats like "Mar 2025", "March 2025", etc.
            date_obj = parse(f"01 {dispensing_month}")
            return date_obj.date()
        except:
            # Fallback to current date if parsing fails
            return datetime.now().date()
    
    def get_or_create_pharmacy(self, pharmacy_data):
        """Get existing pharmacy or create new one."""
        ocs_code = pharmacy_data.get('ocs_code')
        if not ocs_code:
            raise ValueError("OCS code is required")
        
        pharmacy = Pharmacy.query.filter_by(ocs_code=ocs_code).first()
        
        if not pharmacy:
            pharmacy = Pharmacy(
                ocs_code=ocs_code,
                branch_name=pharmacy_data.get('branch_name', ''),
                address=pharmacy_data.get('address', ''),
                postcode=pharmacy_data.get('postcode', '')
            )
            db.session.add(pharmacy)
            db.session.flush()  # Get the ID without committing
        else:
            # Update pharmacy information if provided
            if pharmacy_data.get('branch_name'):
                pharmacy.branch_name = pharmacy_data['branch_name']
            if pharmacy_data.get('address'):
                pharmacy.address = pharmacy_data['address']
            if pharmacy_data.get('postcode'):
                pharmacy.postcode = pharmacy_data['postcode']
            pharmacy.updated_at = datetime.utcnow()
        
        return pharmacy
    
    def create_or_update_financial_record(self, pharmacy, extracted_data, user_id):
        """Create or update financial record for a pharmacy."""
        dispensing_month = extracted_data.get('dispensing_month')
        if not dispensing_month:
            raise ValueError("Dispensing month is required")
        
        dispensing_date = self.parse_dispensing_date(dispensing_month)
        
        # Check for existing record
        existing_record = FinancialRecord.query.filter_by(
            pharmacy_id=pharmacy.id,
            dispensing_date=dispensing_date
        ).first()
        
        if existing_record:
            # Update existing record
            record = existing_record
            record.updated_at = datetime.utcnow()
            is_new = False
        else:
            # Create new record
            record = FinancialRecord(
                pharmacy_id=pharmacy.id,
                dispensing_date=dispensing_date,
                created_by=user_id
            )
            is_new = True
        
        # Update financial data
        record.dispensing_month = dispensing_month
        record.total_account = extracted_data.get('total_account', 0)
        record.drug_appliance_costs = extracted_data.get('drug_appliance_costs', 0)
        record.prescription_fees = extracted_data.get('prescription_fees', 0)
        record.other_fees = extracted_data.get('other_fees', 0)
        record.charges = extracted_data.get('charges', 0)
        
        # Update calculated metrics
        record.drug_costs_percentage = extracted_data.get('drug_costs_percentage', 0)
        record.prescription_fees_percentage = extracted_data.get('prescription_fees_percentage', 0)
        record.other_fees_percentage = extracted_data.get('other_fees_percentage', 0)
        record.total_fees = extracted_data.get('total_fees', 0)
        
        # Update file information
        record.source_file_name = extracted_data.get('file_name')
        record.source_file_path = extracted_data.get('file_path')
        
        if is_new:
            db.session.add(record)
        
        return record, is_new
    
    def process_pdf_file(self, file_path, user_id):
        """Process a single PDF file and store data in database."""
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"File not found: {file_path}")
        
        file_name = os.path.basename(file_path)
        file_size = os.path.getsize(file_path)
        file_hash = self.calculate_file_hash(file_path)
        
        # Check if file has already been processed
        existing_log = UploadLog.query.filter_by(file_hash=file_hash).first()
        if existing_log and existing_log.status == 'completed':
            return {
                'status': 'duplicate',
                'message': f'File {file_name} has already been processed',
                'upload_log_id': existing_log.id
            }
        
        # Create upload log
        upload_log = UploadLog(
            file_name=file_name,
            file_size=file_size,
            file_hash=file_hash,
            uploaded_by=user_id,
            status='processing'
        )
        db.session.add(upload_log)
        db.session.flush()
        
        try:
            # Extract data from PDF
            extracted_data = self.extractor.process_pdf(file_path)
            
            if not extracted_data:
                upload_log.status = 'failed'
                upload_log.error_message = 'Failed to extract data from PDF'
                upload_log.processed_at = datetime.utcnow()
                db.session.commit()
                return {
                    'status': 'failed',
                    'message': 'Failed to extract data from PDF',
                    'upload_log_id': upload_log.id
                }
            
            # Get or create pharmacy
            pharmacy = self.get_or_create_pharmacy(extracted_data)
            
            # Create or update financial record
            financial_record, is_new = self.create_or_update_financial_record(
                pharmacy, extracted_data, user_id
            )
            
            # Update upload log
            upload_log.status = 'completed'
            upload_log.records_created = 1 if is_new else 0
            upload_log.records_updated = 0 if is_new else 1
            upload_log.processed_at = datetime.utcnow()
            
            db.session.commit()
            
            return {
                'status': 'success',
                'message': f'Successfully processed {file_name}',
                'upload_log_id': upload_log.id,
                'pharmacy_id': pharmacy.id,
                'financial_record_id': financial_record.id,
                'is_new_record': is_new,
                'extracted_data': extracted_data
            }
            
        except Exception as e:
            db.session.rollback()
            upload_log.status = 'failed'
            upload_log.error_message = str(e)
            upload_log.processed_at = datetime.utcnow()
            db.session.commit()
            
            return {
                'status': 'failed',
                'message': f'Error processing {file_name}: {str(e)}',
                'upload_log_id': upload_log.id
            }
    
    def process_multiple_pdfs(self, file_paths, user_id):
        """Process multiple PDF files."""
        results = []
        
        for file_path in file_paths:
            result = self.process_pdf_file(file_path, user_id)
            results.append(result)
        
        # Summary statistics
        successful = len([r for r in results if r['status'] == 'success'])
        failed = len([r for r in results if r['status'] == 'failed'])
        duplicates = len([r for r in results if r['status'] == 'duplicate'])
        
        return {
            'results': results,
            'summary': {
                'total_files': len(file_paths),
                'successful': successful,
                'failed': failed,
                'duplicates': duplicates
            }
        }
    
    def get_pharmacy_statistics(self, pharmacy_id=None, start_date=None, end_date=None):
        """Get statistics for pharmacies."""
        query = db.session.query(FinancialRecord).join(Pharmacy)
        
        if pharmacy_id:
            query = query.filter(FinancialRecord.pharmacy_id == pharmacy_id)
        
        if start_date:
            query = query.filter(FinancialRecord.dispensing_date >= start_date)
        
        if end_date:
            query = query.filter(FinancialRecord.dispensing_date <= end_date)
        
        records = query.all()
        
        if not records:
            return None
        
        # Calculate statistics
        total_account = sum(float(r.total_account) for r in records)
        total_drug_costs = sum(float(r.drug_appliance_costs) for r in records)
        total_prescription_fees = sum(float(r.prescription_fees) for r in records)
        total_other_fees = sum(float(r.other_fees) for r in records)
        
        return {
            'total_records': len(records),
            'total_account': total_account,
            'total_drug_costs': total_drug_costs,
            'total_prescription_fees': total_prescription_fees,
            'total_other_fees': total_other_fees,
            'average_account': total_account / len(records),
            'average_drug_costs': total_drug_costs / len(records),
            'drug_costs_percentage': (total_drug_costs / total_account * 100) if total_account > 0 else 0
        }


def test_data_service():
    """Test the data service with sample PDFs."""
    from src.main import app
    
    with app.app_context():
        service = PharmacyDataService(app)
        
        # Test with sample PDFs
        pdf_files = [
            '/home/ubuntu/pharmacy_dashboard/data/Schedule_30-May-2_Pharmacy_FT164.pdf',
            '/home/ubuntu/pharmacy_dashboard/data/Schedule_30-May-2_Pharmacy_FTN39.pdf',
            '/home/ubuntu/pharmacy_dashboard/data/Schedule_30-May-2_Pharmacy_FW682.pdf',
            '/home/ubuntu/pharmacy_dashboard/data/Schedule_30-May-2_Pharmacy_FTT94.pdf'
        ]
        
        # Process files (using user_id = 1 for testing)
        results = service.process_multiple_pdfs(pdf_files, user_id=1)
        
        print("Processing Results:")
        print(f"Total files: {results['summary']['total_files']}")
        print(f"Successful: {results['summary']['successful']}")
        print(f"Failed: {results['summary']['failed']}")
        print(f"Duplicates: {results['summary']['duplicates']}")
        
        for result in results['results']:
            print(f"\nFile: {result.get('message', 'Unknown')}")
            print(f"Status: {result['status']}")
        
        return results


if __name__ == "__main__":
    test_data_service()

