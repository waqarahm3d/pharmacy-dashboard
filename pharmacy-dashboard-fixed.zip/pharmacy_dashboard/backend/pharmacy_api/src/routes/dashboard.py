from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required
from sqlalchemy import func, desc, asc
from datetime import datetime, timedelta
from dateutil.parser import parse
from src.models.pharmacy import db, Pharmacy, FinancialRecord

dashboard_bp = Blueprint('dashboard', __name__)


@dashboard_bp.route('/overview', methods=['GET'])
@jwt_required()
def get_overview():
    """Get dashboard overview data."""
    try:
        # Get query parameters
        start_date = request.args.get('start_date')
        end_date = request.args.get('end_date')
        
        # Base query
        query = db.session.query(FinancialRecord).join(Pharmacy)
        
        # Apply date filters
        if start_date:
            start_date = parse(start_date).date()
            query = query.filter(FinancialRecord.dispensing_date >= start_date)
        
        if end_date:
            end_date = parse(end_date).date()
            query = query.filter(FinancialRecord.dispensing_date <= end_date)
        
        records = query.all()
        
        if not records:
            return jsonify({
                'overview': {
                    'total_pharmacies': 0,
                    'total_records': 0,
                    'total_account_sum': 0,
                    'total_drug_costs': 0,
                    'total_prescription_fees': 0,
                    'total_other_fees': 0,
                    'average_account_per_pharmacy': 0
                },
                'pharmacy_performance': [],
                'monthly_trends': []
            }), 200
        
        # Calculate totals
        total_account_sum = sum(float(record.total_account) for record in records)
        total_drug_costs = sum(float(record.drug_appliance_costs) for record in records)
        total_prescription_fees = sum(float(record.prescription_fees) for record in records)
        total_other_fees = sum(float(record.other_fees) for record in records)
        
        # Get unique pharmacies count
        unique_pharmacies = len(set(record.pharmacy_id for record in records))
        
        # Calculate pharmacy performance
        pharmacy_performance = {}
        for record in records:
            pharmacy_id = record.pharmacy_id
            if pharmacy_id not in pharmacy_performance:
                pharmacy_performance[pharmacy_id] = {
                    'pharmacy_id': pharmacy_id,
                    'pharmacy_name': record.pharmacy.branch_name,
                    'ocs_code': record.pharmacy.ocs_code,
                    'total_account': 0,
                    'drug_costs': 0,
                    'prescription_fees': 0,
                    'other_fees': 0,
                    'record_count': 0
                }
            
            pharmacy_performance[pharmacy_id]['total_account'] += float(record.total_account)
            pharmacy_performance[pharmacy_id]['drug_costs'] += float(record.drug_appliance_costs)
            pharmacy_performance[pharmacy_id]['prescription_fees'] += float(record.prescription_fees)
            pharmacy_performance[pharmacy_id]['other_fees'] += float(record.other_fees)
            pharmacy_performance[pharmacy_id]['record_count'] += 1
        
        # Sort pharmacy performance by total account
        pharmacy_performance_list = sorted(
            pharmacy_performance.values(),
            key=lambda x: x['total_account'],
            reverse=True
        )
        
        # Calculate monthly trends
        monthly_trends = {}
        for record in records:
            month_key = record.dispensing_date.strftime('%Y-%m')
            if month_key not in monthly_trends:
                monthly_trends[month_key] = {
                    'month': month_key,
                    'total_account': 0,
                    'drug_costs': 0,
                    'prescription_fees': 0,
                    'other_fees': 0,
                    'pharmacy_count': set()
                }
            
            monthly_trends[month_key]['total_account'] += float(record.total_account)
            monthly_trends[month_key]['drug_costs'] += float(record.drug_appliance_costs)
            monthly_trends[month_key]['prescription_fees'] += float(record.prescription_fees)
            monthly_trends[month_key]['other_fees'] += float(record.other_fees)
            monthly_trends[month_key]['pharmacy_count'].add(record.pharmacy_id)
        
        # Convert sets to counts and sort by month
        monthly_trends_list = []
        for month_data in monthly_trends.values():
            month_data['pharmacy_count'] = len(month_data['pharmacy_count'])
            monthly_trends_list.append(month_data)
        
        monthly_trends_list.sort(key=lambda x: x['month'])
        
        return jsonify({
            'overview': {
                'total_pharmacies': unique_pharmacies,
                'total_records': len(records),
                'total_account_sum': total_account_sum,
                'total_drug_costs': total_drug_costs,
                'total_prescription_fees': total_prescription_fees,
                'total_other_fees': total_other_fees,
                'average_account_per_pharmacy': total_account_sum / unique_pharmacies if unique_pharmacies > 0 else 0
            },
            'pharmacy_performance': pharmacy_performance_list,
            'monthly_trends': monthly_trends_list
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@dashboard_bp.route('/trends', methods=['GET'])
@jwt_required()
def get_trends():
    """Get detailed trend analysis."""
    try:
        # Get query parameters
        pharmacy_id = request.args.get('pharmacy_id', type=int)
        months = request.args.get('months', default=12, type=int)
        
        # Calculate date range
        end_date = datetime.now().date()
        start_date = end_date - timedelta(days=months * 30)
        
        # Base query
        query = db.session.query(FinancialRecord).join(Pharmacy)
        query = query.filter(FinancialRecord.dispensing_date >= start_date)
        query = query.filter(FinancialRecord.dispensing_date <= end_date)
        
        if pharmacy_id:
            query = query.filter(FinancialRecord.pharmacy_id == pharmacy_id)
        
        records = query.order_by(FinancialRecord.dispensing_date.asc()).all()
        
        # Group by month and calculate trends
        monthly_data = {}
        for record in records:
            month_key = record.dispensing_date.strftime('%Y-%m')
            if month_key not in monthly_data:
                monthly_data[month_key] = {
                    'month': month_key,
                    'date': record.dispensing_date.strftime('%Y-%m-%d'),
                    'total_account': 0,
                    'drug_costs': 0,
                    'prescription_fees': 0,
                    'other_fees': 0,
                    'record_count': 0
                }
            
            monthly_data[month_key]['total_account'] += float(record.total_account)
            monthly_data[month_key]['drug_costs'] += float(record.drug_appliance_costs)
            monthly_data[month_key]['prescription_fees'] += float(record.prescription_fees)
            monthly_data[month_key]['other_fees'] += float(record.other_fees)
            monthly_data[month_key]['record_count'] += 1
        
        # Convert to list and sort
        trends_data = sorted(monthly_data.values(), key=lambda x: x['month'])
        
        # Calculate growth rates
        for i in range(1, len(trends_data)):
            current = trends_data[i]
            previous = trends_data[i-1]
            
            if previous['total_account'] > 0:
                current['total_account_growth'] = ((current['total_account'] - previous['total_account']) / previous['total_account']) * 100
            else:
                current['total_account_growth'] = 0
            
            if previous['drug_costs'] > 0:
                current['drug_costs_growth'] = ((current['drug_costs'] - previous['drug_costs']) / previous['drug_costs']) * 100
            else:
                current['drug_costs_growth'] = 0
        
        # Set first month growth to 0
        if trends_data:
            trends_data[0]['total_account_growth'] = 0
            trends_data[0]['drug_costs_growth'] = 0
        
        return jsonify({
            'trends': trends_data,
            'period': {
                'start_date': start_date.isoformat(),
                'end_date': end_date.isoformat(),
                'months': months
            }
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@dashboard_bp.route('/comparisons', methods=['GET'])
@jwt_required()
def get_comparisons():
    """Get pharmacy comparison data."""
    try:
        # Get query parameters
        metric = request.args.get('metric', default='total_account')
        period = request.args.get('period', default='latest')  # latest, last_3_months, last_6_months
        
        # Calculate date range based on period
        end_date = datetime.now().date()
        if period == 'latest':
            # Get the latest month data
            latest_record = FinancialRecord.query.order_by(desc(FinancialRecord.dispensing_date)).first()
            if latest_record:
                start_date = latest_record.dispensing_date
                end_date = latest_record.dispensing_date
            else:
                start_date = end_date
        elif period == 'last_3_months':
            start_date = end_date - timedelta(days=90)
        elif period == 'last_6_months':
            start_date = end_date - timedelta(days=180)
        else:
            start_date = end_date - timedelta(days=30)
        
        # Query data
        query = db.session.query(
            Pharmacy.id,
            Pharmacy.branch_name,
            Pharmacy.ocs_code,
            func.sum(FinancialRecord.total_account).label('total_account'),
            func.sum(FinancialRecord.drug_appliance_costs).label('drug_costs'),
            func.sum(FinancialRecord.prescription_fees).label('prescription_fees'),
            func.sum(FinancialRecord.other_fees).label('other_fees'),
            func.avg(FinancialRecord.drug_costs_percentage).label('avg_drug_percentage'),
            func.count(FinancialRecord.id).label('record_count')
        ).join(FinancialRecord).filter(
            FinancialRecord.dispensing_date >= start_date,
            FinancialRecord.dispensing_date <= end_date
        ).group_by(Pharmacy.id, Pharmacy.branch_name, Pharmacy.ocs_code)
        
        results = query.all()
        
        # Format results
        comparisons = []
        for result in results:
            comparisons.append({
                'pharmacy_id': result.id,
                'branch_name': result.branch_name,
                'ocs_code': result.ocs_code,
                'total_account': float(result.total_account or 0),
                'drug_costs': float(result.drug_costs or 0),
                'prescription_fees': float(result.prescription_fees or 0),
                'other_fees': float(result.other_fees or 0),
                'avg_drug_percentage': float(result.avg_drug_percentage or 0),
                'record_count': result.record_count
            })
        
        # Sort by selected metric
        if metric in ['total_account', 'drug_costs', 'prescription_fees', 'other_fees']:
            comparisons.sort(key=lambda x: x[metric], reverse=True)
        
        return jsonify({
            'comparisons': comparisons,
            'period': {
                'start_date': start_date.isoformat(),
                'end_date': end_date.isoformat(),
                'period_type': period
            },
            'metric': metric
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@dashboard_bp.route('/export', methods=['GET'])
@jwt_required()
def export_data():
    """Export data for download."""
    try:
        # Get query parameters
        format_type = request.args.get('format', default='json')  # json, csv
        start_date = request.args.get('start_date')
        end_date = request.args.get('end_date')
        pharmacy_id = request.args.get('pharmacy_id', type=int)
        
        # Build query
        query = db.session.query(FinancialRecord).join(Pharmacy)
        
        if start_date:
            start_date = parse(start_date).date()
            query = query.filter(FinancialRecord.dispensing_date >= start_date)
        
        if end_date:
            end_date = parse(end_date).date()
            query = query.filter(FinancialRecord.dispensing_date <= end_date)
        
        if pharmacy_id:
            query = query.filter(FinancialRecord.pharmacy_id == pharmacy_id)
        
        records = query.order_by(FinancialRecord.dispensing_date.desc()).all()
        
        # Format data
        export_data = []
        for record in records:
            export_data.append({
                'pharmacy_name': record.pharmacy.branch_name,
                'ocs_code': record.pharmacy.ocs_code,
                'postcode': record.pharmacy.postcode,
                'dispensing_month': record.dispensing_month,
                'dispensing_date': record.dispensing_date.isoformat(),
                'total_account': float(record.total_account),
                'drug_appliance_costs': float(record.drug_appliance_costs),
                'prescription_fees': float(record.prescription_fees),
                'other_fees': float(record.other_fees),
                'charges': float(record.charges),
                'drug_costs_percentage': float(record.drug_costs_percentage),
                'prescription_fees_percentage': float(record.prescription_fees_percentage),
                'other_fees_percentage': float(record.other_fees_percentage),
                'total_fees': float(record.total_fees)
            })
        
        if format_type == 'csv':
            # Convert to CSV format
            import csv
            import io
            
            output = io.StringIO()
            if export_data:
                writer = csv.DictWriter(output, fieldnames=export_data[0].keys())
                writer.writeheader()
                writer.writerows(export_data)
            
            csv_data = output.getvalue()
            output.close()
            
            return csv_data, 200, {
                'Content-Type': 'text/csv',
                'Content-Disposition': f'attachment; filename=pharmacy_data_{datetime.now().strftime("%Y%m%d")}.csv'
            }
        
        return jsonify({
            'data': export_data,
            'total_records': len(export_data),
            'export_date': datetime.now().isoformat()
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

