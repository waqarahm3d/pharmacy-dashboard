#!/usr/bin/env python3
"""
Database initialization script for pharmacy dashboard
Creates demo user and populates with sample data from PDFs
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from src.models.pharmacy import db, User, Pharmacy, FinancialRecord
from src.main import app
from src.pdf_extractor import PharmacyDataExtractor
import bcrypt
from datetime import datetime

def create_demo_user():
    """Create a demo admin user"""
    # Hash the password
    password_hash = bcrypt.hashpw('admin123'.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')
    
    # Check if user already exists
    existing_user = User.query.filter_by(username='admin').first()
    if existing_user:
        print("Demo user already exists")
        return existing_user
    
    # Create new user
    user = User(
        username='admin',
        email='admin@pharmacy.com',
        password_hash=password_hash,
        role='admin'
    )
    
    db.session.add(user)
    db.session.commit()
    print("Created demo admin user: admin / admin123")
    return user

def populate_sample_data():
    """Populate database with sample data from PDFs"""
    extractor = PharmacyDataExtractor()
    
    # PDF files to process
    pdf_files = [
        '/home/ubuntu/pharmacy_dashboard/data/Schedule_30-May-2_Pharmacy_FT164.pdf',
        '/home/ubuntu/pharmacy_dashboard/data/Schedule_30-May-2_Pharmacy_FTN39.pdf',
        '/home/ubuntu/pharmacy_dashboard/data/Schedule_30-May-2_Pharmacy_FW682.pdf',
        '/home/ubuntu/pharmacy_dashboard/data/Schedule_30-May-2_Pharmacy_FTT94.pdf'
    ]
    
    for pdf_file in pdf_files:
        if not os.path.exists(pdf_file):
            print(f"PDF file not found: {pdf_file}")
            continue
            
        print(f"Processing {pdf_file}...")
        
        try:
            # Extract data from PDF
            data = extractor.process_pdf(pdf_file)
            
            if not data:
                print(f"No data extracted from {pdf_file}")
                continue
            
            # Check if pharmacy already exists
            existing_pharmacy = Pharmacy.query.filter_by(ocs_code=data['ocs_code']).first()
            if not existing_pharmacy:
                # Create pharmacy record
                pharmacy = Pharmacy(
                    ocs_code=data['ocs_code'],
                    branch_name=data['branch_name'],
                    address=data['address'],
                    postcode=data['postcode']
                )
                db.session.add(pharmacy)
                db.session.flush()  # Get the ID
                pharmacy_id = pharmacy.id
            else:
                pharmacy_id = existing_pharmacy.id
                print(f"Pharmacy {data['ocs_code']} already exists")
            
            # Check if financial record already exists
            existing_record = FinancialRecord.query.filter_by(
                pharmacy_id=pharmacy_id,
                dispensing_month=datetime.strptime(data['dispensing_month'], '%Y-%m').date()
            ).first()
            
            if not existing_record:
                # Create financial record
                financial_record = FinancialRecord(
                    pharmacy_id=pharmacy_id,
                    dispensing_month=datetime.strptime(data['dispensing_month'], '%Y-%m').date(),
                    total_account=data['total_account'],
                    drug_appliance_costs=data['drug_appliance_costs'],
                    prescription_fees=data['prescription_fees'],
                    other_fees=data['other_fees']
                )
                db.session.add(financial_record)
                print(f"Added financial record for {data['branch_name']}")
            else:
                print(f"Financial record for {data['branch_name']} already exists")
            
        except Exception as e:
            print(f"Error processing {pdf_file}: {e}")
            continue
    
    db.session.commit()
    print("Sample data population completed")

def main():
    """Initialize database with demo data"""
    with app.app_context():
        # Create tables if they don't exist
        db.create_all()
        
        # Create demo user
        create_demo_user()
        
        # Populate sample data
        populate_sample_data()
        
        print("\nDatabase initialization completed!")
        print("You can now log in with:")
        print("Username: admin")
        print("Password: admin123")

if __name__ == '__main__':
    main()

