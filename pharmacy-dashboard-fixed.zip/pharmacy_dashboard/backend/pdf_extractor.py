#!/usr/bin/env python3
"""
Pharmacy Schedule PDF Data Extractor

This module extracts financial and pharmacy information from NHS pharmacy schedule PDFs.
"""

import pdfplumber
import re
from typing import Dict, Optional, List
from datetime import datetime
import os


class PharmacyDataExtractor:
    """Extract data from NHS pharmacy schedule PDFs."""
    
    def __init__(self):
        self.financial_patterns = {
            'total_account': r'Total of account\s+([£\d,.-]+)',
            'drug_appliance_costs': r'Total of drug and appliance costs\s+([£\d,.-]+)',
            'prescription_fees': r'Sub total of prescription fees\s+([£\d,.-]+)',
            'other_fees': r'Total of all fees\s+([£\d,.-]+)',
            'charges': r'Total of charges \(including FP57 refunds\)\s+([£\d,.-]+)'
        }
        
    def extract_text_from_pdf(self, pdf_path: str) -> str:
        """Extract all text from PDF file."""
        try:
            with pdfplumber.open(pdf_path) as pdf:
                text = ""
                for page in pdf.pages:
                    page_text = page.extract_text()
                    if page_text:
                        text += page_text + "\n"
                return text
        except Exception as e:
            print(f"Error extracting text from {pdf_path}: {e}")
            return ""
    
    def clean_currency_value(self, value: str) -> float:
        """Convert currency string to float value."""
        if not value:
            return 0.0
        
        # Remove £ symbol and any whitespace
        cleaned = value.replace('£', '').strip()
        
        # Handle negative values
        is_negative = cleaned.startswith('-')
        if is_negative:
            cleaned = cleaned[1:]
        
        # Remove commas and convert to float
        try:
            result = float(cleaned.replace(',', ''))
            return -result if is_negative else result
        except ValueError:
            print(f"Warning: Could not convert '{value}' to float")
            return 0.0
    
    def extract_pharmacy_info(self, text: str) -> Dict[str, str]:
        """Extract pharmacy information from PDF text."""
        info = {}
        
        # Extract pharmacy name (after "For:" and before "T/A:")
        name_pattern = r'For:\s+([^\n]+?)(?:\s+T/A:|$)'
        name_match = re.search(name_pattern, text, re.MULTILINE)
        if name_match:
            info['branch_name'] = name_match.group(1).strip()
        
        # Extract trading name if available
        trading_pattern = r'T/A:\s+([^\n]+?)(?:\s+OCS code:|$)'
        trading_match = re.search(trading_pattern, text, re.MULTILINE)
        if trading_match:
            trading_name = trading_match.group(1).strip()
            # If we have a trading name, use it as the branch name
            info['branch_name'] = trading_name
        
        # Extract OCS code
        ocs_pattern = r'OCS code:\s+([A-Z0-9]+)'
        ocs_match = re.search(ocs_pattern, text)
        if ocs_match:
            info['ocs_code'] = ocs_match.group(1).strip()
        
        # Extract address and postcode
        # Look for address pattern after the pharmacy name section
        address_pattern = r'OCS code:\s+[A-Z0-9]+\s+([^\n]+(?:\n[^\n]+)*?)(?:\s+Dispensing Month:|$)'
        address_match = re.search(address_pattern, text, re.MULTILINE | re.DOTALL)
        if address_match:
            address_text = address_match.group(1).strip()
            # Split address lines and clean them
            address_lines = [line.strip() for line in address_text.split('\n') if line.strip()]
            
            if address_lines:
                info['address'] = ', '.join(address_lines)
                
                # Extract postcode (typically the last part of the address)
                postcode_pattern = r'([A-Z]{1,2}\d{1,2}[A-Z]?\s?\d[A-Z]{2})$'
                postcode_match = re.search(postcode_pattern, address_text)
                if postcode_match:
                    info['postcode'] = postcode_match.group(1).strip()
        
        # Extract dispensing month
        month_pattern = r'Dispensing Month:\s+([A-Za-z]+\s+\d{4})'
        month_match = re.search(month_pattern, text)
        if month_match:
            info['dispensing_month'] = month_match.group(1).strip()
        
        return info
    
    def extract_financial_data(self, text: str) -> Dict[str, float]:
        """Extract financial data from PDF text."""
        financial_data = {}
        
        for key, pattern in self.financial_patterns.items():
            match = re.search(pattern, text, re.IGNORECASE)
            if match:
                value = self.clean_currency_value(match.group(1))
                financial_data[key] = value
            else:
                financial_data[key] = 0.0
        
        return financial_data
    
    def extract_additional_metrics(self, financial_data: Dict[str, float]) -> Dict[str, float]:
        """Calculate additional metrics from financial data."""
        metrics = {}
        
        total_account = financial_data.get('total_account', 0)
        drug_costs = financial_data.get('drug_appliance_costs', 0)
        prescription_fees = financial_data.get('prescription_fees', 0)
        other_fees = financial_data.get('other_fees', 0)
        
        # Calculate percentages
        if total_account > 0:
            metrics['drug_costs_percentage'] = (drug_costs / total_account) * 100
            metrics['prescription_fees_percentage'] = (prescription_fees / total_account) * 100
            metrics['other_fees_percentage'] = (other_fees / total_account) * 100
        else:
            metrics['drug_costs_percentage'] = 0
            metrics['prescription_fees_percentage'] = 0
            metrics['other_fees_percentage'] = 0
        
        # Calculate total fees
        metrics['total_fees'] = prescription_fees + other_fees
        
        return metrics
    
    def process_pdf(self, pdf_path: str) -> Optional[Dict]:
        """Process a single PDF file and extract all data."""
        if not os.path.exists(pdf_path):
            print(f"Error: PDF file not found: {pdf_path}")
            return None
        
        print(f"Processing: {pdf_path}")
        
        # Extract text from PDF
        text = self.extract_text_from_pdf(pdf_path)
        if not text:
            print(f"Error: Could not extract text from {pdf_path}")
            return None
        
        # Extract pharmacy information
        pharmacy_info = self.extract_pharmacy_info(text)
        
        # Extract financial data
        financial_data = self.extract_financial_data(text)
        
        # Calculate additional metrics
        additional_metrics = self.extract_additional_metrics(financial_data)
        
        # Combine all data
        result = {
            'file_path': pdf_path,
            'file_name': os.path.basename(pdf_path),
            'extraction_date': datetime.now().isoformat(),
            **pharmacy_info,
            **financial_data,
            **additional_metrics
        }
        
        return result
    
    def process_multiple_pdfs(self, pdf_paths: List[str]) -> List[Dict]:
        """Process multiple PDF files."""
        results = []
        
        for pdf_path in pdf_paths:
            result = self.process_pdf(pdf_path)
            if result:
                results.append(result)
        
        return results


def main():
    """Test the PDF extraction functionality."""
    extractor = PharmacyDataExtractor()
    
    # Get all PDF files in the data directory
    data_dir = "/home/ubuntu/pharmacy_dashboard/data"
    pdf_files = [os.path.join(data_dir, f) for f in os.listdir(data_dir) if f.endswith('.pdf')]
    
    print(f"Found {len(pdf_files)} PDF files to process")
    
    # Process all PDFs
    results = extractor.process_multiple_pdfs(pdf_files)
    
    # Display results
    for result in results:
        print("\n" + "="*80)
        print(f"File: {result['file_name']}")
        print(f"Branch: {result.get('branch_name', 'N/A')}")
        print(f"OCS Code: {result.get('ocs_code', 'N/A')}")
        print(f"Postcode: {result.get('postcode', 'N/A')}")
        print(f"Dispensing Month: {result.get('dispensing_month', 'N/A')}")
        print(f"Total Account: £{result.get('total_account', 0):,.2f}")
        print(f"Drug & Appliance Costs: £{result.get('drug_appliance_costs', 0):,.2f}")
        print(f"Prescription Fees: £{result.get('prescription_fees', 0):,.2f}")
        print(f"Other Fees: £{result.get('other_fees', 0):,.2f}")
        print(f"Drug Costs %: {result.get('drug_costs_percentage', 0):.1f}%")
    
    return results


if __name__ == "__main__":
    main()

