import { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import { 
  TrendingUp, 
  TrendingDown, 
  Building2, 
  FileText, 
  DollarSign,
  Activity,
  ArrowUpRight,
  ArrowDownRight,
  Calendar,
  Download
} from 'lucide-react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { 
  LineChart, 
  Line, 
  AreaChart, 
  Area, 
  BarChart, 
  Bar, 
  PieChart, 
  Pie, 
  Cell,
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer 
} from 'recharts'
import { useAuth } from '../hooks/useAuth'

const Dashboard = () => {
  const { apiCall } = useAuth()
  const [loading, setLoading] = useState(true)
  const [dashboardData, setDashboardData] = useState(null)
  const [timeRange, setTimeRange] = useState('6months')

  useEffect(() => {
    fetchDashboardData()
  }, [timeRange])

  const fetchDashboardData = async () => {
    try {
      setLoading(true)
      const data = await apiCall('/dashboard/overview')
      setDashboardData(data)
    } catch (error) {
      console.error('Error fetching dashboard data:', error)
      // Use mock data for development
      setDashboardData(mockDashboardData)
    } finally {
      setLoading(false)
    }
  }

  // Mock data for development
  const mockDashboardData = {
    overview: {
      total_pharmacies: 4,
      total_records: 12,
      total_account_sum: 282056.13,
      total_drug_costs: 234309.39,
      total_prescription_fees: 45166.49,
      total_other_fees: 59626.49,
      average_account_per_pharmacy: 70514.03
    },
    pharmacy_performance: [
      { pharmacy_name: 'Tile Hill Lane Pharmacy', ocs_code: 'FW682', total_account: 81615.31, drug_costs: 68033.28 },
      { pharmacy_name: 'Wellbeing Pharmacy Toftwood', ocs_code: 'FTN39', total_account: 77177.02, drug_costs: 62575.16 },
      { pharmacy_name: 'Wellbeing Pharmacy Teignmouth', ocs_code: 'FT164', total_account: 75255.90, drug_costs: 62147.03 },
      { pharmacy_name: 'Wellbeing Pharmacy Hartley Wintney', ocs_code: 'FTT94', total_account: 48007.90, drug_costs: 41553.92 }
    ],
    monthly_trends: [
      { month: '2024-09', total_account: 245000, drug_costs: 198000, prescription_fees: 38000 },
      { month: '2024-10', total_account: 258000, drug_costs: 210000, prescription_fees: 40000 },
      { month: '2024-11', total_account: 267000, drug_costs: 218000, prescription_fees: 42000 },
      { month: '2024-12', total_account: 275000, drug_costs: 225000, prescription_fees: 43000 },
      { month: '2025-01', total_account: 280000, drug_costs: 230000, prescription_fees: 44000 },
      { month: '2025-02', total_account: 282056, drug_costs: 234309, prescription_fees: 45166 }
    ]
  }

  const data = dashboardData || mockDashboardData

  const formatCurrency = (value) => {
    return new Intl.NumberFormat('en-GB', {
      style: 'currency',
      currency: 'GBP',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(value)
  }

  const formatPercentage = (value) => {
    return `${value.toFixed(1)}%`
  }

  const calculateGrowth = (current, previous) => {
    if (!previous) return 0
    return ((current - previous) / previous) * 100
  }

  const pieChartData = [
    { name: 'Drug & Appliance Costs', value: data.overview.total_drug_costs, color: '#3b82f6' },
    { name: 'Prescription Fees', value: data.overview.total_prescription_fees, color: '#10b981' },
    { name: 'Other Fees', value: data.overview.total_other_fees, color: '#f59e0b' }
  ]

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {[...Array(4)].map((_, i) => (
            <Card key={i} className="animate-pulse">
              <CardContent className="p-6">
                <div className="h-4 bg-muted rounded w-3/4 mb-2"></div>
                <div className="h-8 bg-muted rounded w-1/2"></div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Dashboard</h1>
          <p className="text-muted-foreground">
            Overview of pharmacy financial performance
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm">
            <Calendar className="w-4 h-4 mr-2" />
            Last 6 months
          </Button>
          <Button variant="outline" size="sm">
            <Download className="w-4 h-4 mr-2" />
            Export
          </Button>
        </div>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
        >
          <Card className="hover:shadow-lg transition-shadow">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">
                    Total Account Value
                  </p>
                  <p className="text-2xl font-bold text-foreground">
                    {formatCurrency(data.overview.total_account_sum)}
                  </p>
                  <div className="flex items-center mt-2">
                    <TrendingUp className="w-4 h-4 text-green-500 mr-1" />
                    <span className="text-sm text-green-500 font-medium">
                      +12.5%
                    </span>
                    <span className="text-sm text-muted-foreground ml-1">
                      vs last month
                    </span>
                  </div>
                </div>
                <div className="p-3 bg-blue-100 dark:bg-blue-900/20 rounded-full">
                  <DollarSign className="w-6 h-6 text-blue-600 dark:text-blue-400" />
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          <Card className="hover:shadow-lg transition-shadow">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">
                    Active Pharmacies
                  </p>
                  <p className="text-2xl font-bold text-foreground">
                    {data.overview.total_pharmacies}
                  </p>
                  <div className="flex items-center mt-2">
                    <Activity className="w-4 h-4 text-green-500 mr-1" />
                    <span className="text-sm text-green-500 font-medium">
                      All active
                    </span>
                  </div>
                </div>
                <div className="p-3 bg-green-100 dark:bg-green-900/20 rounded-full">
                  <Building2 className="w-6 h-6 text-green-600 dark:text-green-400" />
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
        >
          <Card className="hover:shadow-lg transition-shadow">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">
                    Drug & Appliance Costs
                  </p>
                  <p className="text-2xl font-bold text-foreground">
                    {formatCurrency(data.overview.total_drug_costs)}
                  </p>
                  <div className="flex items-center mt-2">
                    <span className="text-sm text-muted-foreground">
                      {formatPercentage((data.overview.total_drug_costs / data.overview.total_account_sum) * 100)} of total
                    </span>
                  </div>
                </div>
                <div className="p-3 bg-purple-100 dark:bg-purple-900/20 rounded-full">
                  <Activity className="w-6 h-6 text-purple-600 dark:text-purple-400" />
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
        >
          <Card className="hover:shadow-lg transition-shadow">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">
                    Total Reports
                  </p>
                  <p className="text-2xl font-bold text-foreground">
                    {data.overview.total_records}
                  </p>
                  <div className="flex items-center mt-2">
                    <TrendingUp className="w-4 h-4 text-green-500 mr-1" />
                    <span className="text-sm text-green-500 font-medium">
                      +4 this month
                    </span>
                  </div>
                </div>
                <div className="p-3 bg-orange-100 dark:bg-orange-900/20 rounded-full">
                  <FileText className="w-6 h-6 text-orange-600 dark:text-orange-400" />
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Monthly Trends */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.5 }}
        >
          <Card>
            <CardHeader>
              <CardTitle>Monthly Trends</CardTitle>
              <CardDescription>
                Financial performance over time
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <AreaChart data={data.monthly_trends}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis />
                  <Tooltip formatter={(value) => formatCurrency(value)} />
                  <Legend />
                  <Area 
                    type="monotone" 
                    dataKey="total_account" 
                    stackId="1"
                    stroke="#3b82f6" 
                    fill="#3b82f6" 
                    fillOpacity={0.6}
                    name="Total Account"
                  />
                  <Area 
                    type="monotone" 
                    dataKey="drug_costs" 
                    stackId="2"
                    stroke="#10b981" 
                    fill="#10b981" 
                    fillOpacity={0.6}
                    name="Drug Costs"
                  />
                </AreaChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </motion.div>

        {/* Cost Breakdown */}
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.6 }}
        >
          <Card>
            <CardHeader>
              <CardTitle>Cost Breakdown</CardTitle>
              <CardDescription>
                Distribution of total costs
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={pieChartData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {pieChartData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip formatter={(value) => formatCurrency(value)} />
                </PieChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </motion.div>
      </div>

      {/* Pharmacy Performance */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.7 }}
      >
        <Card>
          <CardHeader>
            <CardTitle>Pharmacy Performance</CardTitle>
            <CardDescription>
              Top performing pharmacies by total account value
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {data.pharmacy_performance.map((pharmacy, index) => (
                <div key={pharmacy.ocs_code} className="flex items-center justify-between p-4 border border-border rounded-lg hover:bg-accent/50 transition-colors">
                  <div className="flex items-center space-x-4">
                    <div className="flex items-center justify-center w-8 h-8 bg-primary text-primary-foreground rounded-full text-sm font-bold">
                      {index + 1}
                    </div>
                    <div>
                      <p className="font-medium text-foreground">
                        {pharmacy.pharmacy_name}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        OCS: {pharmacy.ocs_code}
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-bold text-foreground">
                      {formatCurrency(pharmacy.total_account)}
                    </p>
                    <p className="text-sm text-muted-foreground">
                      Drug costs: {formatCurrency(pharmacy.drug_costs)}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  )
}

export default Dashboard

