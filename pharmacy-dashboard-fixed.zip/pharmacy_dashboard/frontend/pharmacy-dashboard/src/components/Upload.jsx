import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Upload as UploadIcon } from 'lucide-react'

const Upload = () => {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-foreground">Upload</h1>
        <p className="text-muted-foreground">
          Upload and process pharmacy PDF reports
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <UploadIcon className="w-5 h-5 mr-2" />
            PDF Upload
          </CardTitle>
          <CardDescription>
            Coming soon - PDF upload and processing functionality
          </CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground">
            This section will allow you to upload NHS pharmacy schedule PDFs for automatic data extraction and processing.
          </p>
        </CardContent>
      </Card>
    </div>
  )
}

export default Upload

