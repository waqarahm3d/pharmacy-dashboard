# Pharmacy Dashboard - Deployment Guide

## Overview
This guide provides instructions for deploying the Pharmacy Dashboard application to a VPS server.

## System Requirements
- Ubuntu 20.04+ or similar Linux distribution
- Python 3.11+
- Node.js 20+
- PostgreSQL 12+
- Nginx (for production)
- 2GB+ RAM
- 10GB+ storage

## Pre-deployment Setup

### 1. Server Preparation
```bash
# Update system
sudo apt update && sudo apt upgrade -y

# Install required packages
sudo apt install -y python3.11 python3.11-venv python3-pip nodejs npm postgresql postgresql-contrib nginx git

# Install pnpm
npm install -g pnpm

# Create application user
sudo useradd -m -s /bin/bash pharmacy-dashboard
sudo usermod -aG sudo pharmacy-dashboard
```

### 2. Database Setup
```bash
# Switch to postgres user
sudo -u postgres psql

# Create database and user
CREATE DATABASE pharmacy_dashboard;
CREATE USER pharmacy_user WITH PASSWORD 'your_secure_password_here';
GRANT ALL PRIVILEGES ON DATABASE pharmacy_dashboard TO pharmacy_user;
\q
```

### 3. Application Deployment

#### Backend Deployment
```bash
# Clone or upload application files
cd /home/pharmacy-dashboard
git clone <your-repo> pharmacy-dashboard
cd pharmacy-dashboard/backend/pharmacy_api

# Create virtual environment
python3.11 -m venv venv
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt

# Set environment variables
cat > .env << EOF
DATABASE_URL=postgresql://pharmacy_user:your_secure_password_here@localhost:5432/pharmacy_dashboard
SECRET_KEY=your_super_secret_key_here
JWT_SECRET_KEY=your_jwt_secret_key_here
FLASK_ENV=production
EOF

# Initialize database
python init_db.py

# Test backend
cd src && python main.py
```

#### Frontend Deployment
```bash
# Build frontend
cd /home/pharmacy-dashboard/pharmacy-dashboard/frontend/pharmacy-dashboard

# Install dependencies
pnpm install

# Update API URL for production
# Edit src/hooks/useAuth.jsx and change API_BASE_URL to your server's URL

# Build for production
pnpm run build
```

### 4. Nginx Configuration
```bash
# Create Nginx configuration
sudo tee /etc/nginx/sites-available/pharmacy-dashboard << EOF
server {
    listen 80;
    server_name your-domain.com;

    # Frontend
    location / {
        root /home/pharmacy-dashboard/pharmacy-dashboard/frontend/pharmacy-dashboard/dist;
        try_files \$uri \$uri/ /index.html;
    }

    # Backend API
    location /api {
        proxy_pass http://localhost:5002;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
    }
}
EOF

# Enable site
sudo ln -s /etc/nginx/sites-available/pharmacy-dashboard /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx
```

### 5. Process Management (Systemd)
```bash
# Create systemd service for backend
sudo tee /etc/systemd/system/pharmacy-dashboard.service << EOF
[Unit]
Description=Pharmacy Dashboard Backend
After=network.target

[Service]
Type=simple
User=pharmacy-dashboard
WorkingDirectory=/home/pharmacy-dashboard/pharmacy-dashboard/backend/pharmacy_api/src
Environment=PATH=/home/pharmacy-dashboard/pharmacy-dashboard/backend/pharmacy_api/venv/bin
ExecStart=/home/pharmacy-dashboard/pharmacy-dashboard/backend/pharmacy_api/venv/bin/python main.py
Restart=always

[Install]
WantedBy=multi-user.target
EOF

# Enable and start service
sudo systemctl daemon-reload
sudo systemctl enable pharmacy-dashboard
sudo systemctl start pharmacy-dashboard
```

## Security Considerations

### 1. Firewall Setup
```bash
sudo ufw allow ssh
sudo ufw allow 'Nginx Full'
sudo ufw enable
```

### 2. SSL Certificate (Let's Encrypt)
```bash
sudo apt install certbot python3-certbot-nginx
sudo certbot --nginx -d your-domain.com
```

### 3. Database Security
- Change default PostgreSQL passwords
- Configure pg_hba.conf for restricted access
- Enable SSL for database connections

## Monitoring and Maintenance

### 1. Log Files
- Backend logs: `journalctl -u pharmacy-dashboard -f`
- Nginx logs: `/var/log/nginx/access.log` and `/var/log/nginx/error.log`

### 2. Backup Strategy
```bash
# Database backup
pg_dump -U pharmacy_user pharmacy_dashboard > backup_$(date +%Y%m%d).sql

# Application backup
tar -czf app_backup_$(date +%Y%m%d).tar.gz /home/pharmacy-dashboard/pharmacy-dashboard
```

### 3. Updates
```bash
# Update application
cd /home/pharmacy-dashboard/pharmacy-dashboard
git pull origin main

# Restart services
sudo systemctl restart pharmacy-dashboard
sudo systemctl reload nginx
```

## Troubleshooting

### Common Issues
1. **Database connection errors**: Check PostgreSQL service and credentials
2. **Permission errors**: Ensure correct file ownership and permissions
3. **Port conflicts**: Verify no other services are using required ports
4. **CORS errors**: Update frontend API URLs for production domain

### Health Checks
```bash
# Check backend status
curl http://localhost:5002/api/auth/health

# Check frontend
curl http://localhost/

# Check database
sudo -u postgres psql -d pharmacy_dashboard -c "SELECT COUNT(*) FROM users;"
```

## Performance Optimization

### 1. Database Optimization
- Create indexes on frequently queried columns
- Regular VACUUM and ANALYZE operations
- Connection pooling for high traffic

### 2. Frontend Optimization
- Enable gzip compression in Nginx
- Set appropriate cache headers
- Use CDN for static assets

### 3. Backend Optimization
- Use Gunicorn for production WSGI server
- Implement Redis for session storage
- Add rate limiting for API endpoints

## Support and Maintenance

For ongoing support and maintenance:
1. Monitor system resources (CPU, memory, disk)
2. Regular security updates
3. Database maintenance and backups
4. Log rotation and cleanup
5. Performance monitoring

## Default Credentials

**Admin User:**
- Username: admin
- Password: admin123

**Important:** Change the default admin password immediately after deployment!

