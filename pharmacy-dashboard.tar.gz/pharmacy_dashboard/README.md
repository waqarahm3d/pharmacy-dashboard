# Pharmacy Dashboard - NHS Financial Analytics Platform

A comprehensive web-based dashboard for analyzing NHS pharmacy financial data with automated PDF processing and real-time analytics.

## 🚀 Features

### Core Functionality
- **PDF Data Extraction**: Automatic processing of NHS pharmacy schedule PDFs
- **Financial Analytics**: Real-time analysis of pharmacy financial performance
- **Interactive Dashboard**: Modern, responsive interface with data visualizations
- **Multi-user Support**: Role-based access control (Admin, Manager, Viewer)
- **Data Export**: Export capabilities for reports and analytics

### Key Metrics Tracked
- Total Account Value
- Drug & Appliance Costs
- Prescription Fees
- Other Fees
- Branch Performance Comparisons
- Monthly Trends and Growth Rates

### Technical Features
- **Backend**: Flask REST API with PostgreSQL database
- **Frontend**: React with modern UI components and Recharts for visualization
- **Authentication**: JWT-based secure authentication
- **File Processing**: Automated PDF parsing and data extraction
- **Responsive Design**: Works on desktop, tablet, and mobile devices

## 📊 Dashboard Screenshots

The dashboard includes:
- **Key Metrics Cards**: Overview of financial performance
- **Monthly Trends Chart**: Time-series analysis of financial data
- **Cost Breakdown Pie Chart**: Distribution of different cost categories
- **Pharmacy Performance Table**: Ranking of pharmacies by performance
- **Interactive Navigation**: Clean sidebar with user profile and menu

## 🛠 Technology Stack

### Backend
- **Framework**: Flask (Python 3.11)
- **Database**: PostgreSQL
- **Authentication**: JWT tokens with Flask-JWT-Extended
- **PDF Processing**: pdfplumber for text extraction
- **API**: RESTful API with CORS support

### Frontend
- **Framework**: React 18 with Vite
- **UI Components**: Tailwind CSS with shadcn/ui
- **Charts**: Recharts for data visualization
- **Icons**: Lucide React icons
- **Routing**: React Router for navigation

### Database Schema
- **Users**: Authentication and role management
- **Pharmacies**: Branch information and locations
- **Financial Records**: Monthly financial data
- **Upload Logs**: PDF processing history

## 🚀 Quick Start

### Prerequisites
- Python 3.11+
- Node.js 20+
- PostgreSQL 12+
- Git

### Local Development Setup

1. **Clone the repository**
```bash
git clone <repository-url>
cd pharmacy-dashboard
```

2. **Backend Setup**
```bash
cd backend/pharmacy_api
python3.11 -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
pip install -r requirements.txt

# Setup PostgreSQL database
sudo -u postgres createdb pharmacy_dashboard
sudo -u postgres createuser pharmacy_user

# Initialize database with sample data
python init_db.py
```

3. **Frontend Setup**
```bash
cd frontend/pharmacy-dashboard
pnpm install  # or npm install
```

4. **Start Development Servers**
```bash
# Terminal 1: Backend
cd backend/pharmacy_api/src
python main.py

# Terminal 2: Frontend
cd frontend/pharmacy-dashboard
pnpm run dev
```

5. **Access the Application**
- Frontend: http://localhost:5173
- Backend API: http://localhost:5002

### Default Login Credentials
- **Username**: admin
- **Password**: admin123

## 📁 Project Structure

```
pharmacy-dashboard/
├── backend/
│   └── pharmacy_api/
│       ├── src/
│       │   ├── main.py              # Flask application entry point
│       │   ├── models/              # Database models
│       │   ├── routes/              # API endpoints
│       │   ├── services/            # Business logic
│       │   └── pdf_extractor.py     # PDF processing logic
│       ├── init_db.py               # Database initialization
│       └── requirements.txt         # Python dependencies
├── frontend/
│   └── pharmacy-dashboard/
│       ├── src/
│       │   ├── components/          # React components
│       │   ├── hooks/               # Custom React hooks
│       │   └── App.jsx              # Main application component
│       ├── package.json             # Node.js dependencies
│       └── vite.config.js           # Vite configuration
├── data/                            # Sample PDF files
├── DEPLOYMENT.md                    # Deployment guide
└── README.md                        # This file
```

## 🔧 Configuration

### Environment Variables

Create a `.env` file in the backend directory:

```env
DATABASE_URL=postgresql://pharmacy_user:password@localhost:5432/pharmacy_dashboard
SECRET_KEY=your-secret-key-here
JWT_SECRET_KEY=your-jwt-secret-here
FLASK_ENV=development
```

### Frontend Configuration

Update the API URL in `src/hooks/useAuth.jsx`:

```javascript
const API_BASE_URL = 'http://localhost:5002/api'  // Development
// const API_BASE_URL = 'https://your-domain.com/api'  // Production
```

## 📈 API Documentation

### Authentication Endpoints
- `POST /api/auth/login` - User login
- `POST /api/auth/logout` - User logout
- `GET /api/auth/me` - Get current user info

### Pharmacy Endpoints
- `GET /api/pharmacies` - List all pharmacies
- `GET /api/pharmacies/{id}` - Get pharmacy details
- `POST /api/pharmacies` - Create new pharmacy
- `PUT /api/pharmacies/{id}` - Update pharmacy

### Dashboard Endpoints
- `GET /api/dashboard/metrics` - Get key metrics
- `GET /api/dashboard/trends` - Get trend data
- `GET /api/dashboard/performance` - Get pharmacy performance data

### Upload Endpoints
- `POST /api/upload/pdf` - Upload and process PDF file
- `GET /api/upload/history` - Get upload history

## 🔒 Security Features

- **JWT Authentication**: Secure token-based authentication
- **Role-based Access Control**: Different permissions for different user types
- **CORS Protection**: Configured for secure cross-origin requests
- **Input Validation**: Comprehensive validation for all API inputs
- **SQL Injection Protection**: Using SQLAlchemy ORM with parameterized queries

## 📊 Data Processing

### PDF Extraction Process
1. **File Upload**: Users upload NHS pharmacy schedule PDFs
2. **Text Extraction**: PDF content is extracted using pdfplumber
3. **Data Parsing**: Regular expressions extract structured data
4. **Validation**: Data is validated and cleaned
5. **Database Storage**: Processed data is stored in PostgreSQL
6. **Dashboard Update**: Real-time dashboard updates with new data

### Supported PDF Formats
- NHS Pharmacy Schedule PDFs
- Standard format with OCS codes and financial data
- Monthly dispensing reports

## 🚀 Deployment

For production deployment, see [DEPLOYMENT.md](DEPLOYMENT.md) for detailed instructions including:
- VPS server setup
- Database configuration
- Nginx reverse proxy setup
- SSL certificate installation
- Process management with systemd
- Security hardening

## 🧪 Testing

### Backend Testing
```bash
cd backend/pharmacy_api
python -m pytest tests/
```

### Frontend Testing
```bash
cd frontend/pharmacy-dashboard
pnpm test
```

## 📝 Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add some amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🆘 Support

For support and questions:
1. Check the [DEPLOYMENT.md](DEPLOYMENT.md) guide for deployment issues
2. Review the API documentation above
3. Check the troubleshooting section in the deployment guide

## 🔄 Version History

- **v1.0.0** - Initial release with core functionality
  - PDF processing and data extraction
  - Interactive dashboard with charts
  - User authentication and role management
  - PostgreSQL database integration
  - Responsive React frontend

## 🎯 Future Enhancements

- Advanced reporting and export features
- Email notifications for data updates
- Mobile app for iOS and Android
- Integration with NHS APIs
- Advanced analytics and machine learning insights
- Multi-tenant support for different organizations

---

**Built with ❤️ for NHS pharmacy financial analytics**

