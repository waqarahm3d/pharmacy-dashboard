import { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import { Building2, MapPin, Phone, Mail, Plus, Search, Filter } from 'lucide-react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { useAuth } from '../hooks/useAuth'

const Pharmacies = () => {
  const { apiCall } = useAuth()
  const [pharmacies, setPharmacies] = useState([])
  const [loading, setLoading] = useState(true)
  const [searchQuery, setSearchQuery] = useState('')

  useEffect(() => {
    fetchPharmacies()
  }, [])

  const fetchPharmacies = async () => {
    try {
      setLoading(true)
      const data = await apiCall('/pharmacies/')
      setPharmacies(data.pharmacies || [])
    } catch (error) {
      console.error('Error fetching pharmacies:', error)
      // Use mock data for development
      setPharmacies(mockPharmacies)
    } finally {
      setLoading(false)
    }
  }

  const mockPharmacies = [
    {
      id: 1,
      ocs_code: 'FT164',
      branch_name: 'Wellbeing Pharmacy Teignmouth',
      address: '4 Den Road, Teignmouth, Devon',
      postcode: 'TQ14 8AJ',
      status: 'active'
    },
    {
      id: 2,
      ocs_code: 'FTN39',
      branch_name: 'Wellbeing Pharmacy Toftwood',
      address: '2 Chapel Lane, Toftwood, Dereham, Norfolk',
      postcode: 'NR19 1LD',
      status: 'active'
    },
    {
      id: 3,
      ocs_code: 'FW682',
      branch_name: 'Tile Hill Lane Pharmacy',
      address: '343 Tile Hill Lane, Coventry',
      postcode: 'CV4 9DU',
      status: 'active'
    },
    {
      id: 4,
      ocs_code: 'FTT94',
      branch_name: 'Wellbeing Pharmacy Hartley Wintney',
      address: '74 High Street, Hartley Wintney, Hampshire',
      postcode: 'RG27 8NY',
      status: 'active'
    }
  ]

  const filteredPharmacies = pharmacies.filter(pharmacy =>
    pharmacy.branch_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    pharmacy.ocs_code.toLowerCase().includes(searchQuery.toLowerCase()) ||
    pharmacy.postcode?.toLowerCase().includes(searchQuery.toLowerCase())
  )

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[...Array(6)].map((_, i) => (
            <Card key={i} className="animate-pulse">
              <CardContent className="p-6">
                <div className="h-4 bg-muted rounded w-3/4 mb-2"></div>
                <div className="h-4 bg-muted rounded w-1/2 mb-4"></div>
                <div className="h-16 bg-muted rounded"></div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Pharmacies</h1>
          <p className="text-muted-foreground">
            Manage pharmacy locations and information
          </p>
        </div>
        <Button>
          <Plus className="w-4 h-4 mr-2" />
          Add Pharmacy
        </Button>
      </div>

      {/* Search and filters */}
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Search pharmacies..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>
        <Button variant="outline">
          <Filter className="w-4 h-4 mr-2" />
          Filter
        </Button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Building2 className="w-5 h-5 text-blue-500" />
              <div>
                <p className="text-sm text-muted-foreground">Total</p>
                <p className="text-xl font-bold">{pharmacies.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-green-500 rounded-full"></div>
              <div>
                <p className="text-sm text-muted-foreground">Active</p>
                <p className="text-xl font-bold">{pharmacies.filter(p => p.status === 'active').length}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <MapPin className="w-5 h-5 text-purple-500" />
              <div>
                <p className="text-sm text-muted-foreground">Regions</p>
                <p className="text-xl font-bold">4</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-orange-500 rounded-full"></div>
              <div>
                <p className="text-sm text-muted-foreground">Avg Performance</p>
                <p className="text-xl font-bold">92%</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Pharmacy Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredPharmacies.map((pharmacy, index) => (
          <motion.div
            key={pharmacy.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
          >
            <Card className="hover:shadow-lg transition-all duration-200 cursor-pointer group">
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <div className="flex items-center space-x-3">
                    <div className="p-2 bg-primary/10 rounded-lg group-hover:bg-primary/20 transition-colors">
                      <Building2 className="w-5 h-5 text-primary" />
                    </div>
                    <div>
                      <CardTitle className="text-lg group-hover:text-primary transition-colors">
                        {pharmacy.branch_name}
                      </CardTitle>
                      <CardDescription>
                        OCS: {pharmacy.ocs_code}
                      </CardDescription>
                    </div>
                  </div>
                  <Badge 
                    variant={pharmacy.status === 'active' ? 'default' : 'secondary'}
                    className="capitalize"
                  >
                    {pharmacy.status}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-start space-x-2">
                    <MapPin className="w-4 h-4 text-muted-foreground mt-0.5 flex-shrink-0" />
                    <div>
                      <p className="text-sm text-foreground">{pharmacy.address}</p>
                      {pharmacy.postcode && (
                        <p className="text-sm text-muted-foreground font-mono">
                          {pharmacy.postcode}
                        </p>
                      )}
                    </div>
                  </div>
                  
                  <div className="flex items-center justify-between pt-3 border-t border-border">
                    <div className="flex space-x-2">
                      <Button variant="outline" size="sm">
                        View Details
                      </Button>
                      <Button variant="outline" size="sm">
                        Reports
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      {filteredPharmacies.length === 0 && (
        <div className="text-center py-12">
          <Building2 className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
          <h3 className="text-lg font-medium text-foreground mb-2">
            No pharmacies found
          </h3>
          <p className="text-muted-foreground">
            {searchQuery ? 'Try adjusting your search criteria' : 'Get started by adding your first pharmacy'}
          </p>
        </div>
      )}
    </div>
  )
}

export default Pharmacies

