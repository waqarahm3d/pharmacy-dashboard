import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { BarChart3 } from 'lucide-react'

const Analytics = () => {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-foreground">Analytics</h1>
        <p className="text-muted-foreground">
          Detailed financial analysis and trends
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <BarChart3 className="w-5 h-5 mr-2" />
            Advanced Analytics
          </CardTitle>
          <CardDescription>
            Coming soon - detailed analytics and reporting features
          </CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground">
            This section will include advanced analytics, trend analysis, and detailed reporting capabilities.
          </p>
        </CardContent>
      </Card>
    </div>
  )
}

export default Analytics

