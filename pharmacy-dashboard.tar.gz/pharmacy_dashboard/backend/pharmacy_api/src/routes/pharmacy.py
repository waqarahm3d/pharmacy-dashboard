from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from datetime import datetime
from dateutil.parser import parse
from src.models.pharmacy import db, User, Pharmacy, FinancialRecord, UploadLog
import hashlib
import os

pharmacy_bp = Blueprint('pharmacy', __name__)


@pharmacy_bp.route('/', methods=['GET'])
@jwt_required()
def get_pharmacies():
    """Get all pharmacies."""
    try:
        pharmacies = Pharmacy.query.all()
        return jsonify({
            'pharmacies': [pharmacy.to_dict() for pharmacy in pharmacies]
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@pharmacy_bp.route('/<int:pharmacy_id>', methods=['GET'])
@jwt_required()
def get_pharmacy(pharmacy_id):
    """Get a specific pharmacy."""
    try:
        pharmacy = Pharmacy.query.get_or_404(pharmacy_id)
        return jsonify({'pharmacy': pharmacy.to_dict()}), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@pharmacy_bp.route('/', methods=['POST'])
@jwt_required()
def create_pharmacy():
    """Create a new pharmacy."""
    try:
        current_user_id = get_jwt_identity()
        current_user = User.query.get(current_user_id)
        
        if not current_user or current_user.role.value not in ['admin', 'manager']:
            return jsonify({'error': 'Admin or manager access required'}), 403
        
        data = request.get_json()
        
        if not data or not data.get('ocs_code') or not data.get('branch_name'):
            return jsonify({'error': 'OCS code and branch name are required'}), 400
        
        # Check if pharmacy already exists
        if Pharmacy.query.filter_by(ocs_code=data['ocs_code']).first():
            return jsonify({'error': 'Pharmacy with this OCS code already exists'}), 400
        
        pharmacy = Pharmacy(
            ocs_code=data['ocs_code'],
            branch_name=data['branch_name'],
            address=data.get('address'),
            postcode=data.get('postcode')
        )
        
        db.session.add(pharmacy)
        db.session.commit()
        
        return jsonify({
            'message': 'Pharmacy created successfully',
            'pharmacy': pharmacy.to_dict()
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500


@pharmacy_bp.route('/<int:pharmacy_id>/financial-records', methods=['GET'])
@jwt_required()
def get_financial_records(pharmacy_id):
    """Get financial records for a pharmacy."""
    try:
        pharmacy = Pharmacy.query.get_or_404(pharmacy_id)
        
        # Get query parameters
        start_date = request.args.get('start_date')
        end_date = request.args.get('end_date')
        limit = request.args.get('limit', type=int)
        
        query = FinancialRecord.query.filter_by(pharmacy_id=pharmacy_id)
        
        # Apply date filters
        if start_date:
            start_date = parse(start_date).date()
            query = query.filter(FinancialRecord.dispensing_date >= start_date)
        
        if end_date:
            end_date = parse(end_date).date()
            query = query.filter(FinancialRecord.dispensing_date <= end_date)
        
        # Order by date descending
        query = query.order_by(FinancialRecord.dispensing_date.desc())
        
        # Apply limit
        if limit:
            query = query.limit(limit)
        
        records = query.all()
        
        return jsonify({
            'pharmacy': pharmacy.to_dict(),
            'financial_records': [record.to_dict() for record in records],
            'total_records': len(records)
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@pharmacy_bp.route('/<int:pharmacy_id>/financial-records', methods=['POST'])
@jwt_required()
def create_financial_record(pharmacy_id):
    """Create a new financial record for a pharmacy."""
    try:
        current_user_id = get_jwt_identity()
        current_user = User.query.get(current_user_id)
        
        if not current_user or current_user.role.value not in ['admin', 'manager']:
            return jsonify({'error': 'Admin or manager access required'}), 403
        
        pharmacy = Pharmacy.query.get_or_404(pharmacy_id)
        data = request.get_json()
        
        if not data or not data.get('dispensing_month'):
            return jsonify({'error': 'Dispensing month is required'}), 400
        
        # Parse dispensing date
        try:
            dispensing_date = parse(data['dispensing_month']).date()
        except:
            return jsonify({'error': 'Invalid dispensing month format'}), 400
        
        # Check for duplicate record
        existing_record = FinancialRecord.query.filter_by(
            pharmacy_id=pharmacy_id,
            dispensing_date=dispensing_date
        ).first()
        
        if existing_record:
            return jsonify({'error': 'Financial record for this month already exists'}), 400
        
        # Create financial record
        record = FinancialRecord(
            pharmacy_id=pharmacy_id,
            dispensing_month=data['dispensing_month'],
            dispensing_date=dispensing_date,
            total_account=data.get('total_account', 0),
            drug_appliance_costs=data.get('drug_appliance_costs', 0),
            prescription_fees=data.get('prescription_fees', 0),
            other_fees=data.get('other_fees', 0),
            charges=data.get('charges', 0),
            drug_costs_percentage=data.get('drug_costs_percentage', 0),
            prescription_fees_percentage=data.get('prescription_fees_percentage', 0),
            other_fees_percentage=data.get('other_fees_percentage', 0),
            total_fees=data.get('total_fees', 0),
            source_file_name=data.get('source_file_name'),
            created_by=current_user_id
        )
        
        db.session.add(record)
        db.session.commit()
        
        return jsonify({
            'message': 'Financial record created successfully',
            'financial_record': record.to_dict()
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500


@pharmacy_bp.route('/upload-logs', methods=['GET'])
@jwt_required()
def get_upload_logs():
    """Get upload logs."""
    try:
        current_user_id = get_jwt_identity()
        current_user = User.query.get(current_user_id)
        
        # Admins can see all logs, others only their own
        if current_user.role.value == 'admin':
            logs = UploadLog.query.order_by(UploadLog.uploaded_at.desc()).all()
        else:
            logs = UploadLog.query.filter_by(uploaded_by=current_user_id).order_by(UploadLog.uploaded_at.desc()).all()
        
        return jsonify({
            'upload_logs': [log.to_dict() for log in logs]
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@pharmacy_bp.route('/summary', methods=['GET'])
@jwt_required()
def get_summary():
    """Get summary statistics."""
    try:
        # Get counts
        total_pharmacies = Pharmacy.query.count()
        total_records = FinancialRecord.query.count()
        
        # Get latest records
        latest_records = FinancialRecord.query.order_by(FinancialRecord.dispensing_date.desc()).limit(5).all()
        
        # Calculate totals for latest month
        if latest_records:
            latest_date = latest_records[0].dispensing_date
            latest_month_records = FinancialRecord.query.filter_by(dispensing_date=latest_date).all()
            
            total_account_sum = sum(float(record.total_account) for record in latest_month_records)
            total_drug_costs = sum(float(record.drug_appliance_costs) for record in latest_month_records)
            total_prescription_fees = sum(float(record.prescription_fees) for record in latest_month_records)
            total_other_fees = sum(float(record.other_fees) for record in latest_month_records)
        else:
            total_account_sum = 0
            total_drug_costs = 0
            total_prescription_fees = 0
            total_other_fees = 0
        
        return jsonify({
            'summary': {
                'total_pharmacies': total_pharmacies,
                'total_records': total_records,
                'latest_month_totals': {
                    'total_account': total_account_sum,
                    'drug_appliance_costs': total_drug_costs,
                    'prescription_fees': total_prescription_fees,
                    'other_fees': total_other_fees
                }
            },
            'latest_records': [record.to_dict() for record in latest_records]
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

